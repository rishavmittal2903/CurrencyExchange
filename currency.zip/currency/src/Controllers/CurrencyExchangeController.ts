import { Router, Request, Response, NextFunction } from "express";
import { CurrencyCSVProvider } from "../Provider/CurrencyCSVProvider";
export const CurrencyExchangeRouter = Router();

CurrencyExchangeRouter.get(
  "/",
  async (request: Request, response: Response, next: NextFunction) => {
    const csvString = await CurrencyCSVProvider();
    if (csvString) {
      response.send(csvString);
    } else {
      response.send(500);
    }
  }
);
