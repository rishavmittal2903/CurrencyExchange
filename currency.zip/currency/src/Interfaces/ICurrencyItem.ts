export interface ICurrencyItem{
    code:string;
    name:string;
}