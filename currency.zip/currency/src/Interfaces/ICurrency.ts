export interface ICurrency {
  exchangeRate: number;
  fromCurrencyCode: string;
  fromCurrencyName: string;
  toCurrencyCode: string;
  toCurrencyName: string;
}


export interface ICurrencyList{
    currencyList: Array<ICurrency>;
}