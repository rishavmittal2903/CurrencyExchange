export interface ICSVFormat{
    currencyCode:string;
    countryName:string;
    currencyExchangeRate:number;
    path:string;
}