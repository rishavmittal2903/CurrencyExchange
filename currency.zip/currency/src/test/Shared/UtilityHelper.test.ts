import { CurrencyExchange } from "../../Provider/CurrencyExchange";
import { bindRate, joinArrayWithDelimiter } from "../../Shared/UtilityHelper";
import { mockedCurrencyData } from "../mockData/mockData";
import { ICurrencyItem } from "../../Interfaces/ICurrencyItem";

describe("UtilityHelper test cases", () => {
  test("Should returned the joined array result with delimiter", () => {
    const actualData: Array<string> = ["test", "test1"];
    const result: any = joinArrayWithDelimiter(actualData, " | ");
    expect(result).toBe("test | test1");
  });
  test("Should returned the binded rate data if rates object doesnot have currency code", () => {
    const currencyExchangeObj = new CurrencyExchange(mockedCurrencyData);
    const testCurrencyCode = "test";
    const response = bindRate(currencyExchangeObj, testCurrencyCode, "test");
    expect(response).toHaveLength(43);
    const index = currencyExchangeObj.currencyItem.findIndex(
      (item: ICurrencyItem) => item.code === testCurrencyCode
    );
    expect(index).not.toBe(-1);
  });
  test("Should returned the existing binded rate data if rates object have currency code", () => {
    const currencyExchangeObj = new CurrencyExchange(mockedCurrencyData);
    const response:Array<ICurrencyItem> = bindRate(currencyExchangeObj, "ETH", "test");
    const index = currencyExchangeObj.currencyItem.findIndex(
      (item: ICurrencyItem) => item.code === "ETH"
    );
    expect(response[index].name).not.toBe('test');

  });
});
