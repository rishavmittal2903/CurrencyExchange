export const mockedCurrencyData = [
  {
    exchangeRate: 6.150460895496756,
    fromCurrencyCode: "CAD",
    fromCurrencyName: "Canada Dollar",
    toCurrencyCode: "HKD",
    toCurrencyName: "Hong Kong Dollar",
  },
  {
    exchangeRate: 0.797615493386334,
    fromCurrencyCode: "CAD",
    fromCurrencyName: "Canada Dollar",
    toCurrencyCode: "USD",
    toCurrencyName: "USA Dollar",
  },
  {
    exchangeRate: 0.5719423123753048,
    fromCurrencyCode: "USD",
    fromCurrencyName: "USA Dollar",
    toCurrencyCode: "HKD",
    toCurrencyName: "Hong Kong Dollar",
  },
  {
    exchangeRate: 4.126475758625669,
    fromCurrencyCode: "CAD",
    fromCurrencyName: "Canada Dollar",
    toCurrencyCode: "BRL",
    toCurrencyName: "Brazil Real",
  },
  {
    exchangeRate: 0.6763347114599059,
    fromCurrencyCode: "CAD",
    fromCurrencyName: "Canada Dollar",
    toCurrencyCode: "EUR",
    toCurrencyName: "Euro",
  },
  {
    exchangeRate: 6.462962312024309,
    fromCurrencyCode: "HKD",
    fromCurrencyName: "Hong Kong Dollar",
    toCurrencyCode: "PHP",
    toCurrencyName: "Philippines Peso",
  },
  {
    exchangeRate: 9.478489847827468,
    fromCurrencyCode: "HKD",
    fromCurrencyName: "Hong Kong Dollar",
    toCurrencyCode: "INR",
    toCurrencyName: "India Rupee",
  },
  {
    exchangeRate: 2946.686215835865,
    fromCurrencyCode: "HKD",
    fromCurrencyName: "Hong Kong Dollar",
    toCurrencyCode: "VND",
    toCurrencyName: "Vietnam Dong",
  },
  {
    exchangeRate: 23.653327699444155,
    fromCurrencyCode: "PHP",
    fromCurrencyName: "Philippines Peso",
    toCurrencyCode: "KRW",
    toCurrencyName: "South Korea Won",
  },
  {
    exchangeRate: 0.0011108072027318614,
    fromCurrencyCode: "KRW",
    fromCurrencyName: "South Korea Won",
    toCurrencyCode: "SGD",
    toCurrencyName: "Singapore Dollar",
  },
  {
    exchangeRate: 24.60630286681223,
    fromCurrencyCode: "SGD",
    fromCurrencyName: "Singapore Dollar",
    toCurrencyCode: "THB",
    toCurrencyName: "Thailand Baht",
  },
  {
    exchangeRate: 110.4859145456322,
    fromCurrencyCode: "USD",
    fromCurrencyName: "USA Dollar",
    toCurrencyCode: "JPY",
    toCurrencyName: "Japan Yen",
  },
  {
    exchangeRate: 19.959162719461506,
    fromCurrencyCode: "USD",
    fromCurrencyName: "USA Dollar",
    toCurrencyCode: "MXN",
    toCurrencyName: "Mexico Peso",
  },
  {
    exchangeRate: 3.7858696132132534,
    fromCurrencyCode: "USD",
    fromCurrencyName: "USA Dollar",
    toCurrencyCode: "SAR",
    toCurrencyName: "Saudi Arabia Riyal",
  },
  {
    exchangeRate: 11.443625953387611,
    fromCurrencyCode: "SAR",
    fromCurrencyName: "Saudi Arabia Riyal",
    toCurrencyCode: "UYU",
    toCurrencyName: "Uruguay Peso",
  },
  {
    exchangeRate: 46.04338728186392,
    fromCurrencyCode: "SAR",
    fromCurrencyName: "Saudi Arabia Riyal",
    toCurrencyCode: "LRD",
    toCurrencyName: "Liberia Dollar",
  },
  {
    exchangeRate: 118.21184331857528,
    fromCurrencyCode: "SAR",
    fromCurrencyName: "Saudi Arabia Riyal",
    toCurrencyCode: "SDG",
    toCurrencyName: "Sudan Pound",
  },
  {
    exchangeRate: 0.8000865686246835,
    fromCurrencyCode: "LRD",
    fromCurrencyName: "Liberia Dollar",
    toCurrencyCode: "DZD",
    toCurrencyName: "Algeria Dinar",
  },
  {
    exchangeRate: 238.4478308288189,
    fromCurrencyCode: "GBP",
    fromCurrencyName: "Great Britain Pound",
    toCurrencyCode: "LRD",
    toCurrencyName: "Liberia Dollar",
  },
  {
    exchangeRate: 2105.4132956664957,
    fromCurrencyCode: "GBP",
    fromCurrencyName: "Great Britain Pound",
    toCurrencyCode: "LBP",
    toCurrencyName: "Lebanon Pound",
  },
  {
    exchangeRate: 11.99634016072625,
    fromCurrencyCode: "GBP",
    fromCurrencyName: "Great Britain Pound",
    toCurrencyCode: "NOK",
    toCurrencyName: "Norway Kroner",
  },
  {
    exchangeRate: 1.0023267128842668,
    fromCurrencyCode: "NOK",
    fromCurrencyName: "Norway Kroner",
    toCurrencyCode: "SEK",
    toCurrencyName: "Sweden Krona",
  },
  {
    exchangeRate: 0.98580476035852,
    fromCurrencyCode: "SEK",
    fromCurrencyName: "Sweden Krona",
    toCurrencyCode: "TRY",
    toCurrencyName: "Turkish New Lira",
  },
  {
    exchangeRate: 0.11038783720606424,
    fromCurrencyCode: "SEK",
    fromCurrencyName: "Sweden Krona",
    toCurrencyCode: "CHF",
    toCurrencyName: "Switzerland Franc",
  },
  {
    exchangeRate: 1.3029274004450913,
    fromCurrencyCode: "BRL",
    fromCurrencyName: "Brazil Real",
    toCurrencyCode: "TTD",
    toCurrencyName: "Trinidad/Tobago Dollar",
  },
  {
    exchangeRate: 8.206856467856365,
    fromCurrencyCode: "BRL",
    fromCurrencyName: "Brazil Real",
    toCurrencyCode: "UYU",
    toCurrencyName: "Uruguay Peso",
  },
  {
    exchangeRate: 0.06536460486190554,
    fromCurrencyCode: "UYU",
    fromCurrencyName: "Uruguay Peso",
    toCurrencyCode: "TND",
    toCurrencyName: "Tunisia Dinar",
  },
  {
    exchangeRate: 18.980652045914557,
    fromCurrencyCode: "BRL",
    fromCurrencyName: "Brazil Real",
    toCurrencyCode: "ARS",
    toCurrencyName: "Argentina Peso",
  },
  {
    exchangeRate: 1.6609791636224132,
    fromCurrencyCode: "EUR",
    fromCurrencyName: "Euro",
    toCurrencyCode: "NZD",
    toCurrencyName: "New Zealand Dollar",
  },
  {
    exchangeRate: 1.603661593783909,
    fromCurrencyCode: "EUR",
    fromCurrencyName: "Euro",
    toCurrencyCode: "AUD",
    toCurrencyName: "Australia Dollar",
  },
  {
    exchangeRate: 2.40170581660473,
    fromCurrencyCode: "EUR",
    fromCurrencyName: "Euro",
    toCurrencyCode: "BZD",
    toCurrencyName: "Belize Dollar",
  },
  {
    exchangeRate: 0.41164782974482983,
    fromCurrencyCode: "BBD",
    fromCurrencyName: "Barbados Dollar",
    toCurrencyCode: "KYD",
    toCurrencyName: "Cayman Islands Dollar",
  },
  {
    exchangeRate: 6.453609330387402,
    fromCurrencyCode: "USD",
    fromCurrencyName: "USA Dollar",
    toCurrencyCode: "CNY",
    toCurrencyName: "China Yuan/Renminbi",
  },
  {
    exchangeRate: 1.2203060762512308,
    fromCurrencyCode: "CNY",
    fromCurrencyName: "China Yuan/Renminbi",
    toCurrencyCode: "HKD",
    toCurrencyName: "Hong Kong Dollar",
  },
  {
    exchangeRate: 0.8574720022911398,
    fromCurrencyCode: "EUR",
    fromCurrencyName: "Euro",
    toCurrencyCode: "GBP",
    toCurrencyName: "Great Britain Pound",
  },
  {
    exchangeRate: 0.00001814602691340264,
    fromCurrencyCode: "CAD",
    fromCurrencyName: "Canada Dollar",
    toCurrencyCode: "BTC",
    toCurrencyName: "Bitcoin",
  },
  {
    exchangeRate: 14.258474865285667,
    fromCurrencyCode: "BTC",
    fromCurrencyName: "Bitcoin",
    toCurrencyCode: "ETH",
    toCurrencyName: "Ethereum",
  },
  {
    exchangeRate: 4983402.050757109,
    fromCurrencyCode: "BTC",
    fromCurrencyName: "Bitcoin",
    toCurrencyCode: "BAN",
    toCurrencyName: "Banano",
  },
  {
    exchangeRate: 8489.90238638007,
    fromCurrencyCode: "BTC",
    fromCurrencyName: "Bitcoin",
    toCurrencyCode: "NANO",
    toCurrencyName: "Nano",
  },
  {
    exchangeRate: 2.4302623922919473,
    fromCurrencyCode: "NANO",
    fromCurrencyName: "Nano",
    toCurrencyCode: "ADA",
    toCurrencyName: "Cardano",
  },
  {
    exchangeRate: 24.172355499380043,
    fromCurrencyCode: "NANO",
    fromCurrencyName: "Nano",
    toCurrencyCode: "DOGE",
    toCurrencyName: "Dogecoin",
  },
  {
    exchangeRate: 0.013321677628866442,
    fromCurrencyCode: "ADA",
    fromCurrencyName: "Cardano",
    toCurrencyCode: "LTC",
    toCurrencyName: "Litecoin",
  },
  {
    exchangeRate: 1.1646040026693611,
    fromCurrencyCode: "ADA",
    fromCurrencyName: "Cardano",
    toCurrencyCode: "ALGO",
    toCurrencyName: "Algorand",
  },
  {
    exchangeRate: 0.003844617292937624,
    fromCurrencyCode: "ALGO",
    fromCurrencyName: "Alogorand",
    toCurrencyCode: "BCH",
    toCurrencyName: "BitcoinCash",
  },
  {
    exchangeRate: 77.22238848982447,
    fromCurrencyCode: "BTC",
    fromCurrencyName: "Bitcoin",
    toCurrencyCode: "BCH",
    toCurrencyName: "BitcoinCash",
  },
];

export const expectedCurrencyCSVData=`currencyCode,countryName,currencyExchangeRate,path
HKD,Hong Kong Dollar,629.980896120519,CAD | USD | CNY | HKD
USD,USA Dollar,1071.7669543107966,CAD | HKD | USD
BRL,Brazil Real,5606.142227658262,CAD | HKD | USD | SAR | UYU | BRL
EUR,Euro,921.5459877075052,CAD | HKD | USD | SAR | LRD | GBP | EUR
PHP,Philippines Peso,4051.7661092371286,CAD | USD | CNY | HKD | PHP
INR,India Rupee,5959.872797923864,CAD | USD | CNY | HKD | INR
VND,Vietnam Dong,1860156.8536113708,CAD | USD | CNY | HKD | VND
KRW,South Korea Won,95466.75578323996,CAD | USD | CNY | HKD | PHP | KRW
SGD,Singapore Dollar,105.58242232950596,CAD | USD | CNY | HKD | PHP | KRW | SGD
THB,Thailand Baht,2604.133442201228,CAD | USD | CNY | HKD | PHP | KRW | SGD | THB
JPY,Japan Yen,118794.4654426744,CAD | HKD | USD | JPY
MXN,Mexico Peso,21319.042049186235,CAD | HKD | USD | MXN
SAR,Saudi Arabia Riyal,4049.106468699175,CAD | HKD | USD | SAR
UYU,Uruguay Peso,46317.76583756853,CAD | HKD | USD | SAR | UYU
LRD,Liberia Dollar,186360.65672936058,CAD | HKD | USD | SAR | LRD
SDG,Sudan Pound,478577.5682516372,CAD | HKD | USD | SAR | SDG
DZD,Algeria Dinar,149912.2059139772,CAD | HKD | USD | SAR | LRD | DZD
GBP,Great Britain Pound,785.9708695032873,CAD | HKD | USD | SAR | LRD | GBP
LBP,Lebanon Pound,1660863.1705001988,CAD | HKD | USD | SAR | LRD | GBP | LBP
NOK,Norway Kroner,9446.987734265329,CAD | HKD | USD | SAR | LRD | GBP | NOK
SEK,Sweden Krona,9472.869404569195,CAD | HKD | USD | SAR | LRD | GBP | NOK | SEK
TRY,Turkish New Lira,9317.268232704457,CAD | HKD | USD | SAR | LRD | GBP | NOK | SEK | TRY
CHF,Switzerland Franc,1050.9077285960157,CAD | HKD | USD | SAR | LRD | GBP | NOK | SEK | CHF
TTD,Trinidad/Tobago Dollar,7298.926573952838,CAD | HKD | USD | SAR | UYU | BRL | TTD
TND,Tunisia Dinar,3037.6763978469107,CAD | HKD | USD | SAR | UYU | TND
ARS,Argentina Peso,105627.21988054703,CAD | HKD | USD | SAR | UYU | BRL | ARS
NZD,New Zealand Dollar,1535.7487751749502,CAD | HKD | USD | SAR | LRD | GBP | EUR | NZD
AUD,Australia Dollar,1483.493903521431,CAD | HKD | USD | SAR | LRD | GBP | EUR | AUD
BZD,Belize Dollar,2207.889699025402,CAD | HKD | USD | SAR | LRD | GBP | EUR | BZD
BBD,Barbados Dollar,-1,
KYD,Cayman Islands Dollar,-1,
CNY,China Yuan/Renminbi,6952.93346385845,CAD | HKD | USD | CNY
BTC,Bitcoin,0.0018177453431355334,CAD | BTC
ETH,Ethereum,0.025750567140583967,CAD | BTC | ETH
BAN,Banano,9061.732839912438,CAD | BTC | BAN
NANO,Nano,15.308198300289671,CAD | BTC | NANO
ADA,Cardano,37.020105343715905,CAD | BTC | NANO | ADA
DOGE,Dogecoin,368.47444184854015,CAD | BTC | NANO | DOGE
LTC,Litecoin,0.49096307431558994,CAD | BTC | NANO | ADA | LTC
ALGO,Algorand,42.876871501465814,CAD | BTC | NANO | ADA | ALGO
BCH,BitcoinCash,0.164328935590362,CAD | BTC | NANO | ADA | ALGO | BCH
`