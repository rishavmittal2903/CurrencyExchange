import { CurrencyCSVProvider } from "../../Provider/CurrencyCSVProvider";
import { expectedCurrencyCSVData, mockedCurrencyData } from "../mockData/mockData";
import axios from 'axios';

describe("CurrencyCSVProvider", () => {
  jest.mock("axios");
  const mockedAxios = axios as jest.Mocked<typeof axios>;

  test("Should returned the csv string format if data is available", async() => {
    axios.get = jest.fn(() => mockedCurrencyData);
    mockedAxios.get.mockResolvedValue({
      data: mockedCurrencyData,
    });    
    const result: any = await CurrencyCSVProvider();
    expect(result).toEqual(expectedCurrencyCSVData);
  });
});
