import { ICurrencyItem } from "../Interfaces/ICurrencyItem";
import { CurrencyExchange } from "../Provider/CurrencyExchange";

export const bindRate = (
  currencyContext: CurrencyExchange,
  currencyCode: string,
  currencyName: string
): Array<ICurrencyItem> => {
  if (!currencyContext.rates[currencyCode]) {
    currencyContext.rates[currencyCode] = [];
    currencyContext.currencyItem.push({
      code: currencyCode,
      name: currencyName,
    });
  }
  return currencyContext.currencyItem;
};

export const joinArrayWithDelimiter = (
  path: Array<string>,
  delimiter: string
): string => {
  return path.join(delimiter);
};