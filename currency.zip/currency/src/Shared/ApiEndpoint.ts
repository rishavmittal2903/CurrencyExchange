const baseUrl = "https://api-coding-challenge.neofinancial.com/";
export const currencyExchangeUrl = () =>
  `${baseUrl}currency-conversion?seed=44036`;
