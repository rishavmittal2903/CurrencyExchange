export const default_currency_code = "CAD"
export const default_amount = 100.0;
export const defaultExchangeRate = 1.0;