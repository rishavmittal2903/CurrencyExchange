import { ICSVFormat } from "../Interfaces/ICSVFormat";
import { CurrencyExchange } from "./CurrencyExchange";
import { getCurrencyConversionData } from "../Provider/CurrencyExchangeProvider";
import ObjectsToCsv from "objects-to-csv";
import { default_amount, default_currency_code } from "../Shared/Constant";
export const CurrencyCSVProvider = async ():Promise<string> => {
  try {
    const currencyData = await getCurrencyConversionData();
    const currencyExchangeObj = new CurrencyExchange(currencyData.data);

    const csvFormat: Array<ICSVFormat> = [];
    for (let { code, name } of currencyExchangeObj.currencyItem) {
      let currencyCode = code;
      let currencyName = name;
      if (default_currency_code != currencyCode) {
        const { rate, path } = currencyExchangeObj.getBestExchangeRateAndPath(
          default_currency_code,
          currencyCode,
          default_amount
        );
        csvFormat.push({
          currencyCode: currencyCode,
          countryName: currencyName,
          currencyExchangeRate: rate,
          path,
        });
      }
    }
    const csv = new ObjectsToCsv(csvFormat);
    const fileName = `currencyExchange-${new Date().toLocaleTimeString()}.csv`;
    await csv.toDisk(`./${fileName}`);
    return await csv.toString();
  } catch (ex) {
    console.log(ex);
    return "";
  }
};
