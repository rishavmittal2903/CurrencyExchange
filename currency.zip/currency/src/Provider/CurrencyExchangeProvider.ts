import { currencyExchangeUrl } from "../Shared/ApiEndpoint";
import { httpClient } from "../Shared/AxiosClient";

export const getCurrencyConversionData = async () => {
  const data: any = await httpClient(
    currencyExchangeUrl(),
    "GET"
  );
  return data;
};
