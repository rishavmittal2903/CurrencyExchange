import { ICurrency } from "../Interfaces/ICurrency";
import { ICurrencyItem } from "../Interfaces/ICurrencyItem";
import { defaultExchangeRate } from "../Shared/Constant";
import { bindRate, joinArrayWithDelimiter } from "../Shared/UtilityHelper";

export class CurrencyExchange {
  currencyItem: Array<ICurrencyItem>=[];
  rates: any={};
  visited: any={};
  exchangeRate: number=-defaultExchangeRate;
  path: Array<string>=[];
  constructor(data: Array<ICurrency>) {
    this.addInitialData(data);
  }

  addRatesData(
    fromCurrencyCode: string,
    toCurrencyCode: string,
    fromCurrencyName: string,
    toCurrencyName: string,
    exRate: number
  ) {
    bindRate(this, fromCurrencyCode, fromCurrencyName);
    bindRate(this, toCurrencyCode, toCurrencyName);
    this.rates[fromCurrencyCode].push({ to_currency_code:toCurrencyCode, ex_rate:exRate });
  }

  addInitialData(currencyData: Array<ICurrency>) {
    const mappedObj: any = {};
    for (let currency of currencyData) {
      this.addRatesData(
        currency.fromCurrencyCode,
        currency.toCurrencyCode,
        currency.fromCurrencyName,
        currency.toCurrencyName,
        currency.exchangeRate
      );
      mappedObj[`${currency.fromCurrencyCode}-${currency.toCurrencyCode}`] =
      currency.exchangeRate;
    }
    // Add reversed exchange rate if not provided
    for (let currency of currencyData) {
      if (!mappedObj[`${currency.toCurrencyCode}-${currency.fromCurrencyCode}`]) {
        this.addRatesData(
          currency.toCurrencyCode,
          currency.fromCurrencyCode,
          currency.toCurrencyName,
          currency.fromCurrencyName,
          1 / currency.exchangeRate
        );
      }
    }
  }

  findRateAndPath(
    currentCurrency: string,
    targetCurrency: string,
    amount: number,
    conversionPath: Array<string>,
    currencyStack: Array<any>
  ) {
    this.visited[currentCurrency] = true;
    let value: any = currencyStack[currencyStack.length - 1] * amount;
    currencyStack.push(parseFloat(value));
    conversionPath.push(currentCurrency);

    if (currentCurrency == targetCurrency) {
      let current_amount = currencyStack[currencyStack.length - 1];
      if (current_amount > this.exchangeRate) {
        this.exchangeRate = parseFloat(current_amount);
        this.path = Object.assign([], conversionPath);
      }
    } else {
      for (let { to_currency_code, ex_rate } of this.rates[
        currentCurrency
      ]) {
        if (!this.visited[to_currency_code]) {
          this.findRateAndPath(
            to_currency_code,
            targetCurrency,
            ex_rate,
            conversionPath,
            currencyStack
          );
        }
      }
    }
    currencyStack.pop();
    conversionPath.pop();
    this.visited[currentCurrency] = false;
  }
  getBestExchangeRateAndPath(
    original_currency: string,
    target_currency: string,
    amount: number
  ) {
    this.exchangeRate = -defaultExchangeRate;
    this.path = [];
    for (let {code} of this.currencyItem) {
      this.visited[code] = false;
    }
    this.findRateAndPath(
      original_currency,
      target_currency,
      amount,
      [],
      [defaultExchangeRate]
    );
    return {
      rate: this.exchangeRate,
      path: joinArrayWithDelimiter(this.path, " | "),
    };
  }
}

