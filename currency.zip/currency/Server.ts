import cors from "cors";
import Express, { NextFunction, Request, Response } from "express";
import { CurrencyExchangeRouter } from "./src/Controllers/CurrencyExchangeController";

const app = Express();
var port = process.env.PORT || 8081;
app.use(cors());
app.use("/api/currencyExchange", CurrencyExchangeRouter);

app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  const { statusCode, message } = err;
  res.status(statusCode).json({
    status: "Error",
    statusCode,
    message
  });
});
app.listen(port, () => console.log("Http server started on port " + port));
