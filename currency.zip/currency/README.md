# Currency Exchange API 
## Technology

- Node js
- TypeScript
- Jest as testing library
- Export CSV using objects-to-csv package

## Description

```sh
Api to get the best currency exchange rate and conversion path. It will responsible to save the currencyConversion data into same repository as CSV format and send csv format into string as response

```

## Api(http://localhost:8081/api/currencyExchange) response

```sh
URL- http://localhost:8081/api/currencyExchange
Method-Type: GET
Response: 
currencyCode,countryName,currencyExchangeRate,path
HKD,Hong Kong Dollar,629.980896120519,CAD | USD | CNY | HKD
```
## Detail Explaintation of product

Application divided into three layer Client, controller, provider layer

- Client layer will handle the routes and call the controller(CurrencyExchangeController)
- Controller will hit the provider layer which will be responsible to bind the logic
- Provider layer responsible to export currencyexchange data in csv format

## CurrencyExchange Provider

It is typescript class pattern which has constructor to bind the initial data into properties. CurrencyExchange Class has four methods:- `addInitialData`, `addRatesData`, `findRateAndPath`, `getBestExchangeRateAndPath`

`addInitialData`:- Initially add the rates for from and to `CurrencyCode,CurrencyName` into currencyItem and push exchange rate into rates list with respect to from currencyCode. `It will also store the reveresed exchange rate if not provided`

`addRatesData`: create rates list with respect to currency code

`findRateAndPath`: This method implements the DFS algorithm. which mark each vertex as visited while avoiding cycles and figure out the exchange rate and path

`getBestExchangeRateAndPath`: This method internally call the finalRateAndPath method to get best exchange rate and convert the path into specific format with delimiter " | " for csv

## CurrencyCSVExchange Provider

This method call the http client api to fetch currency data and pass to CurrencyExchange class to prepare data for csv format and save csv data into repository and return same csv format into string

## Installation steps
```sh
npm install
Install the dependency packages
```
```sh
npm start
Responsible to build the typescript files into javascript files and start server with port 8081 if no specific port defined in the env file
```
```sh
npm run test
Responsible to run all the unit test cases and generate the test coverage report with coverage folder in the repository
```
